package com.example.studentinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class courses extends AppCompatActivity {
    ArrayList<String> cname = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);
        ListView lview;
        lview = findViewById(R.id.lview);

        cname.add("Maths");
        cname.add("Ml");
        cname.add("AL");
        cname.add("Statistics");
        cname.add("Python");
        cname.add("Java");
        cname.add("C");
        cname.add("DBMS");
        cname.add("SQL");
        cname.add("Chem");
        cname.add("Big Data");
        cname.add("Idsa");
        cname.add("SSDI");
        cname.add("Economics");
        cname.add("Probability");
        cname.add("AAD");


        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, cname);
        lview.setAdapter(adapter);
        lview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {

                    Toast.makeText(getApplicationContext() ,"Maths is Clicked",Toast.LENGTH_SHORT).show();

                }
            }
        });


    }
}