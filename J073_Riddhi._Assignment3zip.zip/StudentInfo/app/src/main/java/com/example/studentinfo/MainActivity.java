package com.example.studentinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button home,aboutus,course;
        Intent ihome,iabt,icourse;
        home=findViewById(R.id.home);
        aboutus=findViewById(R.id.aboutus);
        course=findViewById(R.id.course);

        ihome= new Intent(this,Home.class);
        iabt=new Intent(this,about_us.class);
        icourse=new Intent(this,courses.class);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(ihome);

            }
        });
        aboutus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(iabt);

            }
        });
        course.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(icourse);

            }
        });




    }
}